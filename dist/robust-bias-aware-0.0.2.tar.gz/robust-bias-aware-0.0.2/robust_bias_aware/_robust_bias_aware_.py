
import robust_bias_aware
import argparse
import warnings
# import pandas as pd
    # for key, value in kwargs.items():
    # print(kwargs)

robust_bias_aware.robust_bias_aware(seeds='./data/data-case-study-1-covid-19/covid-19-seeds.txt', outfile='covid19.graphml')